package example;

// Environment code for project almoxarifado

import jason.asSyntax.*;
import jason.environment.*;
import jason.asSyntax.parser.*;

import java.text.ParseException;
import java.util.logging.*;

public class Env extends Environment {

    private Logger logger = Logger.getLogger("almoxarifado."+Env.class.getName());
    String peca_sorteada = "peca(peq)";

    /** Called before the MAS execution with the args informed in .mas2j */
    @Override
    public void init(String[] args) {
        super.init(args);
        try {
            addPercept(ASSyntax.parseLiteral(peca_sorteada));
            addPercept(ASSyntax.parseLiteral("dia(quarta)"));
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean executeAction(String agName, Structure action) {
        
        if (agName.equals("r1") && action.toString().equals("guardar(peq)")) { // you may improve this condition
            logger.info(agName + " está guardando peça pequena....");
        } else {
            logger.info("executing: "+action+", but not implemented!");
        }

        try {
            removePercept(ASSyntax.parseLiteral(peca_sorteada));                        
        } catch (Exception e) {
            e.printStackTrace();
        }

        return true; // the action was executed with success
    }

    /** Called before the end of MAS execution */
    @Override
    public void stop() {
        super.stop();
    }
}
