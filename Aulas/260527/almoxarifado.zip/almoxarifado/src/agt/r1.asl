
!start.

+!start : true 
    <- .print("guardo peças pequenas").

+peca(Tamanho) : Tamanho = peq
    <- .print("percebi uma peça ", Tamanho, " e vou guarda-la");
       guardar(Tamanho).