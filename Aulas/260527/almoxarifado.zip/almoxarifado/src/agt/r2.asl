
!start.

+!start : true  
    <- .print("guardo peças médias").
